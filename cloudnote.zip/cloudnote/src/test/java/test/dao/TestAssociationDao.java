package test.dao;

import org.junit.Test;

import com.tedu.cloudnote.dao.AssociationDao;
import com.tedu.cloudnote.entity.Book;

import test.service.BaseTest;

public class TestAssociationDao extends BaseTest {
	
	@Test
	public void test1(){
		AssociationDao dao =
			ac.getBean("associationDao",AssociationDao.class);
		Book book = dao.findById("e46239d6-4f54-426c-a448-f7a0d45f9425");
		System.out.println("�ʼǱ�����"+book.getCn_notebook_name());
		System.out.println("����ʱ�䣺"+book.getCn_notebook_createtime());
		System.out.println("�����û���:");
	}

}
