package cloudnote;

import org.springframework.jdbc.datasource.DataSourceTransactionManager;

public class test {
	//BasicDataSource
	//SqlSessionFactoryBean
	//MapperScannerConfigurer
//	DataSourceTransactionManager

}
