package com.tedu.cloudnote.dao;

import com.tedu.cloudnote.entity.Book;

public interface AssociationDao {
	
	public Book findById(String bookId);

}
